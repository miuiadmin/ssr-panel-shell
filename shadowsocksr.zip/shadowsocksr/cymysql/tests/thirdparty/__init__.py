from test_MySQLdb import *

if __name__ == "__main__":
    import unittest
    unittest.main()
